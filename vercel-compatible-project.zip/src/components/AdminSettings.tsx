import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import {
  Send, Save, LogOut, Loader2, CheckCircle2, AlertCircle,
  Bot, MessageSquare, Power, ExternalLink, TestTube2,
} from 'lucide-react';

interface AdminSettingsProps {
  onLogout: () => void;
  onBack: () => void;
}

interface TelegramConfig {
  id: string;
  bot_token: string;
  chat_id: string;
  is_enabled: boolean;
}

export default function AdminSettings({ onLogout, onBack }: AdminSettingsProps) {
  const [config, setConfig] = useState<TelegramConfig | null>(null);
  const [botToken, setBotToken] = useState('');
  const [chatId, setChatId] = useState('');
  const [isEnabled, setIsEnabled] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const loadConfig = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('telegram_config')
      .select('*')
      .limit(1)
      .maybeSingle();

    if (error) {
      setMessage({ type: 'error', text: error.message });
    } else if (data) {
      setConfig(data);
      setBotToken(data.bot_token || '');
      setChatId(data.chat_id || '');
      setIsEnabled(data.is_enabled);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    loadConfig();
  }, [loadConfig]);

  const handleSave = async () => {
    setSaving(true);
    setMessage(null);

    try {
      if (config) {
        const { error } = await supabase
          .from('telegram_config')
          .update({
            bot_token: botToken,
            chat_id: chatId,
            is_enabled: isEnabled,
            updated_at: new Date().toISOString(),
          })
          .eq('id', config.id);

        if (error) throw error;
      } else {
        const { data, error } = await supabase
          .from('telegram_config')
          .insert({
            bot_token: botToken,
            chat_id: chatId,
            is_enabled: isEnabled,
          })
          .select()
          .maybeSingle();

        if (error) throw error;
        if (data) setConfig(data);
      }

      setMessage({ type: 'success', text: 'Telegram configuration saved successfully.' });
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'Failed to save configuration';
      setMessage({ type: 'error', text: errorMsg });
    } finally {
      setSaving(false);
    }
  };

  const handleTest = async () => {
    if (!botToken || !chatId) {
      setMessage({ type: 'error', text: 'Please enter a bot token and chat ID before testing.' });
      return;
    }

    setTesting(true);
    setMessage(null);

    try {
      // Save first so the edge function can read the latest config
      if (config) {
        await supabase
          .from('telegram_config')
          .update({
            bot_token: botToken,
            chat_id: chatId,
            is_enabled: true,
            updated_at: new Date().toISOString(),
          })
          .eq('id', config.id);
      } else {
        const { data } = await supabase
          .from('telegram_config')
          .insert({
            bot_token: botToken,
            chat_id: chatId,
            is_enabled: true,
          })
          .select()
          .maybeSingle();
        if (data) setConfig(data);
      }
      setIsEnabled(true);

      // Call the edge function with a test payload
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/telegram-notify`;
      const res = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({
          event: 'test',
          fullName: 'Admin Test',
          phoneNumber: '0000000000',
          timestamp: new Date().toISOString(),
        }),
      });

      if (!res.ok) {
        const errText = await res.text();
        setMessage({ type: 'error', text: `Test failed (${res.status}): ${errText}` });
      } else {
        const result = await res.json();
        if (result.sent) {
          setMessage({ type: 'success', text: 'Test message sent to your Telegram. Check your chat!' });
        } else {
          setMessage({ type: 'error', text: result.error || result.reason || 'Test did not send a message.' });
        }
      }
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'Test failed';
      setMessage({ type: 'error', text: errorMsg });
    } finally {
      setTesting(false);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    onLogout();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <Loader2 size={32} className="animate-spin text-blue-400" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4">
      <div className="max-w-2xl mx-auto py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
              <Bot size={22} className="text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">Telegram Notifications</h1>
              <p className="text-slate-400 text-sm">Configure where form submissions are sent</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onBack}
              className="text-slate-400 hover:text-white transition px-3 py-2 rounded-lg hover:bg-slate-800"
            >
              View site
            </button>
            <button
              onClick={handleLogout}
              className="inline-flex items-center gap-2 text-slate-300 hover:text-white border border-slate-700 hover:border-slate-600 px-3 py-2 rounded-lg transition"
            >
              <LogOut size={18} />
              Logout
            </button>
          </div>
        </div>

        {/* Status banner */}
        <div
          className={`rounded-xl p-4 mb-6 border flex items-center gap-3 ${
            isEnabled
              ? 'bg-green-500/10 border-green-500/30'
              : 'bg-amber-500/10 border-amber-500/30'
          }`}
        >
          <Power size={20} className={isEnabled ? 'text-green-400' : 'text-amber-400'} />
          <p className={isEnabled ? 'text-green-300 text-sm' : 'text-amber-300 text-sm'}>
            {isEnabled
              ? 'Notifications are ON. New submissions will be pushed to Telegram.'
              : 'Notifications are OFF. No messages will be sent until you enable them.'}
          </p>
        </div>

        {/* Message */}
        {message && (
          <div
            className={`rounded-xl p-4 mb-6 border flex items-start gap-3 ${
              message.type === 'success'
                ? 'bg-green-500/10 border-green-500/30'
                : 'bg-red-500/10 border-red-500/30'
            }`}
          >
            {message.type === 'success' ? (
              <CheckCircle2 size={20} className="text-green-400 mt-0.5 shrink-0" />
            ) : (
              <AlertCircle size={20} className="text-red-400 mt-0.5 shrink-0" />
            )}
            <p className={message.type === 'success' ? 'text-green-300 text-sm' : 'text-red-300 text-sm'}>
              {message.text}
            </p>
          </div>
        )}

        {/* Config form */}
        <div className="bg-slate-800/60 backdrop-blur-sm border border-slate-700 rounded-2xl p-6 sm:p-8 space-y-6">
          {/* Enable toggle */}
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white font-medium">Enable notifications</p>
              <p className="text-slate-400 text-sm">Master switch for all Telegram pushes</p>
            </div>
            <button
              onClick={() => setIsEnabled(!isEnabled)}
              className={`relative w-14 h-7 rounded-full transition-colors duration-200 ${
                isEnabled ? 'bg-green-500' : 'bg-slate-600'
              }`}
            >
              <span
                className={`absolute top-1 left-1 w-5 h-5 bg-white rounded-full transition-transform duration-200 ${
                  isEnabled ? 'translate-x-7' : ''
                }`}
              />
            </button>
          </div>

          <div className="border-t border-slate-700" />

          {/* Bot token */}
          <div>
            <label className="flex items-center gap-2 text-sm text-slate-300 mb-2">
              <Bot size={16} />
              Bot Token
            </label>
            <input
              type="text"
              value={botToken}
              onChange={(e) => setBotToken(e.target.value)}
              className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:ring-2 focus:ring-blue-400 focus:border-transparent outline-none transition font-mono text-sm"
              placeholder="123456789:ABCdefGHIjklMNOpqrSTUvwxYZ"
            />
            <p className="text-slate-500 text-xs mt-2">
              Get this from{' '}
              <a
                href="https://t.me/BotFather"
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-400 hover:underline inline-flex items-center gap-1"
              >
                @BotFather <ExternalLink size={12} />
              </a>{' '}
              after creating a bot.
            </p>
          </div>

          {/* Chat ID */}
          <div>
            <label className="flex items-center gap-2 text-sm text-slate-300 mb-2">
              <MessageSquare size={16} />
              Chat ID
            </label>
            <input
              type="text"
              value={chatId}
              onChange={(e) => setChatId(e.target.value)}
              className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:ring-2 focus:ring-blue-400 focus:border-transparent outline-none transition font-mono text-sm"
              placeholder="-1001234567890"
            />
            <p className="text-slate-500 text-xs mt-2">
              Your chat or channel ID. Message your bot first, then use{' '}
              <a
                href="https://t.me/userinfobot"
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-400 hover:underline inline-flex items-center gap-1"
              >
                @userinfobot <ExternalLink size={12} />
              </a>{' '}
              to find it.
            </p>
          </div>

          {/* Action buttons */}
          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <button
              onClick={handleSave}
              disabled={saving}
              className="flex-1 inline-flex items-center justify-center gap-2 bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white font-semibold py-3 rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {saving ? (
                <>
                  <Loader2 size={20} className="animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save size={20} />
                  Save Configuration
                </>
              )}
            </button>
            <button
              onClick={handleTest}
              disabled={testing}
              className="flex-1 inline-flex items-center justify-center gap-2 bg-slate-700 hover:bg-slate-600 text-white font-semibold py-3 rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {testing ? (
                <>
                  <Loader2 size={20} className="animate-spin" />
                  Sending test...
                </>
              ) : (
                <>
                  <TestTube2 size={20} />
                  Send Test Message
                </>
              )}
            </button>
          </div>
        </div>

        {/* Info card */}
        <div className="mt-6 bg-slate-800/40 border border-slate-700/50 rounded-xl p-5">
          <div className="flex items-start gap-3">
            <Send size={18} className="text-blue-400 mt-0.5 shrink-0" />
            <div className="text-slate-400 text-sm space-y-2">
              <p className="text-slate-300 font-medium">How it works</p>
              <p>When a visitor spins the wheel, submits their details, enters their OTP, or qualifies, a notification is automatically pushed to your Telegram chat with their details and data package amount.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
