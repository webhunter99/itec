export function GcashLogo({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 120 40" className={className} xmlns="http://www.w3.org/2000/svg" aria-label="GCash">
      <rect x="0" y="0" width="120" height="40" rx="8" fill="#007DDC" />
      <text
        x="60"
        y="27"
        textAnchor="middle"
        fontSize="18"
        fontWeight="800"
        fontFamily="Arial, sans-serif"
        fill="white"
        letterSpacing="0.5"
      >
        GCash
      </text>
    </svg>
  );
}
