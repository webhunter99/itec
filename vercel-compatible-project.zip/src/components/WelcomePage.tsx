import { Satellite, Wifi, Zap, Shield, ArrowRight, Star, Globe } from 'lucide-react';

interface WelcomePageProps {
  onNext: () => void;
}

export default function WelcomePage({ onNext }: WelcomePageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-950 relative overflow-hidden">
      {/* Starfield background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[
          { top: '8%', left: '12%', size: 2, delay: '0s' },
          { top: '15%', left: '75%', size: 3, delay: '1s' },
          { top: '30%', left: '40%', size: 1.5, delay: '2s' },
          { top: '55%', left: '85%', size: 2, delay: '0.5s' },
          { top: '70%', left: '20%', size: 2.5, delay: '1.5s' },
          { top: '82%', left: '60%', size: 1.5, delay: '0.8s' },
          { top: '45%', left: '10%', size: 2, delay: '2.5s' },
          { top: '90%', left: '45%', size: 2, delay: '1.2s' },
        ].map((star, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-cyan-200 animate-pulse"
            style={{
              top: star.top,
              left: star.left,
              width: `${star.size}px`,
              height: `${star.size}px`,
              animationDelay: star.delay,
            }}
          />
        ))}
        <div className="absolute top-10 right-10 text-blue-500/10 animate-pulse" style={{ animationDelay: '0s' }}>
          <Satellite size={140} />
        </div>
        <div className="absolute bottom-20 left-8 text-cyan-500/10 animate-pulse" style={{ animationDelay: '1.5s' }}>
          <Globe size={100} />
        </div>
      </div>

      <div className="relative min-h-screen flex flex-col items-center justify-center px-6 py-12">
        <div className="w-full max-w-2xl text-center">
          {/* Logo badge */}
          <div className="inline-flex items-center justify-center mb-8 animate-in fade-in zoom-in duration-700">
            <div className="relative">
              <div className="absolute inset-0 bg-cyan-500 blur-2xl opacity-50 rounded-full" />
              <div className="relative bg-gradient-to-br from-cyan-500 to-blue-600 w-24 h-24 rounded-full flex items-center justify-center shadow-2xl shadow-cyan-500/30">
                <Satellite size={48} className="text-white" />
              </div>
            </div>
          </div>

          {/* Brand name */}
          <div className="mb-3 animate-in fade-in slide-in-from-top-4 duration-700 delay-150">
            <h1 className="text-4xl sm:text-6xl font-bold tracking-tight">
              <span className="text-white">Starlink</span>{' '}
              <span className="bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                Data Packages
              </span>
            </h1>
          </div>

          {/* Tagline */}
          <p className="text-cyan-200 text-lg sm:text-xl mb-2 animate-in fade-in slide-in-from-top-4 duration-700 delay-300">
            Rate & win premium internet data plans
          </p>
          <p className="text-slate-400 text-sm sm:text-base mb-12 max-w-md mx-auto animate-in fade-in slide-in-from-top-4 duration-700 delay-500">
            Spin the wheel for your chance to win Starlink data packages. Fast, reliable satellite internet — straight to your device.
          </p>

          {/* Feature cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-12">
            <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all duration-300 hover:scale-105 animate-in fade-in slide-in-from-bottom-4 duration-700 delay-700">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-cyan-500/20 mb-4">
                <Zap size={24} className="text-cyan-300" />
              </div>
              <h3 className="text-white font-semibold mb-2">Lightning Speed</h3>
              <p className="text-slate-400 text-sm">Up to 300 Mbps with low-latency satellite tech</p>
            </div>

            <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all duration-300 hover:scale-105 animate-in fade-in slide-in-from-bottom-4 duration-700 delay-1000">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-blue-500/20 mb-4">
                <Wifi size={24} className="text-blue-300" />
              </div>
              <h3 className="text-white font-semibold mb-2">Always Connected</h3>
              <p className="text-slate-400 text-sm">Reliable internet anywhere across the Philippines</p>
            </div>

            <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all duration-300 hover:scale-105 animate-in fade-in slide-in-from-bottom-4 duration-700 delay-[1300ms]">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-indigo-500/20 mb-4">
                <Shield size={24} className="text-indigo-300" />
              </div>
              <h3 className="text-white font-semibold mb-2">Secure Network</h3>
              <p className="text-slate-400 text-sm">Encrypted satellite uplink protects your connection</p>
            </div>
          </div>

          {/* Stats bar */}
          <div className="flex items-center justify-center gap-8 mb-12 animate-in fade-in duration-700 delay-[1600ms]">
            <div className="text-center">
              <div className="text-3xl font-bold text-white">120K+</div>
              <div className="text-cyan-300/70 text-xs uppercase tracking-wide mt-1">Subscribers</div>
            </div>
            <div className="w-px h-12 bg-white/10" />
            <div className="text-center">
              <div className="text-3xl font-bold text-white">45K+</div>
              <div className="text-cyan-300/70 text-xs uppercase tracking-wide mt-1">Packages Won</div>
            </div>
            <div className="w-px h-12 bg-white/10" />
            <div className="text-center">
              <div className="flex items-center gap-1 justify-center">
                <span className="text-3xl font-bold text-white">4.8</span>
                <Star size={20} className="text-amber-400" fill="currentColor" />
              </div>
              <div className="text-cyan-300/70 text-xs uppercase tracking-wide mt-1">Rating</div>
            </div>
          </div>

          {/* CTA button */}
          <button
            onClick={onNext}
            className="group inline-flex items-center gap-3 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-bold text-lg px-10 py-4 rounded-full shadow-xl shadow-cyan-500/30 transition-all duration-300 hover:shadow-2xl hover:shadow-cyan-500/40 hover:scale-105 animate-in fade-in zoom-in duration-700 delay-[1900ms]"
          >
            Get Started
            <ArrowRight size={22} className="group-hover:translate-x-1 transition-transform" />
          </button>

          <p className="text-slate-500 text-xs mt-6 animate-in fade-in duration-700 delay-[2200ms]">
            Free to join · No credit card required
          </p>
        </div>
      </div>
    </div>
  );
}
