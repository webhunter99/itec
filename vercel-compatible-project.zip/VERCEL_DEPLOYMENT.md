# Deploying this project to Vercel

## Vercel project settings
- Framework preset: **Vite**
- Root directory: **project** (if importing the parent repository/archive)
- Build command: `npm run build`
- Output directory: `dist`
- Install command: `npm install`

## Environment variables
In Vercel: Project → Settings → Environment Variables, add:

- `VITE_SUPABASE_URL` = your Supabase project URL
- `VITE_SUPABASE_ANON_KEY` = your Supabase anon/public publishable key

Add them for Production, Preview, and Development as needed, then redeploy.
Do not put a Supabase `service_role` key in a `VITE_` variable or in frontend code.

## Deploy
1. Extract this archive.
2. Import the `project` folder into Vercel (or set Root Directory to `project`).
3. Add the two Supabase environment variables above.
4. Deploy.

`vercel.json` includes an SPA rewrite so client-side routes and direct refreshes serve `index.html`.
The original Netlify config is retained but is not used by Vercel.
