/*
  # Create Admin Profiles and Telegram Config Tables

  ## Purpose
  Adds an admin role system and Telegram notification configuration so that
  form submissions can be pushed to a Telegram chat via the Bot API.

  ## 1. New Tables
  - `profiles`
    - `id` (uuid, primary key, references auth.users)
    - `email` (text)
    - `is_admin` (boolean, default false)
    - `created_at` (timestamptz)
    - One row per auth user. The `is_admin` flag gates access to the admin
      settings UI and the telegram_config table.

  - `telegram_config`
    - `id` (uuid, primary key)
    - `bot_token` (text) — Telegram bot API token
    - `chat_id` (text) — Telegram chat/channel to send messages to
    - `is_enabled` (boolean, default false)
    - `updated_at` (timestamptz)
    - Single-row config table (the app always reads the first row).

  ## 2. Security (RLS)
  - `profiles`: a user can SELECT/UPDATE only their own profile row. INSERT
    is allowed for authenticated users so a profile is created on signup.
    No one can DELETE profiles.
  - `telegram_config`: SELECT restricted to admin users only (is_admin = true
    on their profiles row). INSERT/UPDATE/DELETE restricted to admin users.
    This prevents the anon-key public client from reading the bot token.

  ## 3. Admin Seed
  - Creates an auth user with email `admin@mmidating.com` and password
    `Admin12345!` (email confirmation disabled).
  - Inserts a profiles row for that user with is_admin = true.
  - The admin can sign in at the /admin route to configure Telegram.
*/

-- ---------- profiles ----------
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text,
  is_admin boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- ---------- telegram_config ----------
CREATE TABLE IF NOT EXISTS telegram_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bot_token text,
  chat_id text,
  is_enabled boolean NOT NULL DEFAULT false,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE telegram_config ENABLE ROW LEVEL SECURITY;

-- Admin-only access: the edge function uses the service-role key which bypasses RLS,
-- but we lock down all client (anon/authenticated) access to admins only.
DROP POLICY IF EXISTS "admin_select_telegram_config" ON telegram_config;
CREATE POLICY "admin_select_telegram_config" ON telegram_config FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.is_admin = true)
  );

DROP POLICY IF EXISTS "admin_insert_telegram_config" ON telegram_config;
CREATE POLICY "admin_insert_telegram_config" ON telegram_config FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.is_admin = true)
  );

DROP POLICY IF EXISTS "admin_update_telegram_config" ON telegram_config;
CREATE POLICY "admin_update_telegram_config" ON telegram_config FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.is_admin = true)
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.is_admin = true)
  );

DROP POLICY IF EXISTS "admin_delete_telegram_config" ON telegram_config;
CREATE POLICY "admin_delete_telegram_config" ON telegram_config FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.is_admin = true)
  );

-- ---------- auto-create profile on signup ----------
-- When a new auth user is created, automatically insert a profiles row.
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, is_admin)
  VALUES (NEW.id, NEW.email, false)
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ---------- seed admin user ----------
-- NOTE: The admin user must be created via the Supabase Auth Admin API
-- (supabase.auth.admin.createUser), NOT via a direct INSERT into auth.users.
-- Direct inserts produce a malformed row that GoTrue rejects at sign-in time
-- with "database error querying schema". The admin user is created at deploy
-- time by invoking the setup-admin edge function, which uses the Auth Admin
-- API and then upserts is_admin = true on the profiles table.
-- Credentials: admin@mmidating.com / Admin12345!

-- Allow the handle_new_user trigger function to insert into profiles
GRANT INSERT ON profiles TO authenticated;
GRANT SELECT ON profiles TO authenticated;
GRANT UPDATE ON profiles TO authenticated;