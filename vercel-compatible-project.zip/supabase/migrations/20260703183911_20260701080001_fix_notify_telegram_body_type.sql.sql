/*
  # Fix notify_telegram: body param must be jsonb not text

  pg_net's net.http_post expects `body` as jsonb (not text).
  The previous version cast payload to text which caused:
    function net.http_post(url => text, headers => jsonb, body => text) does not exist
  This updates the call to pass body as jsonb directly.
*/

CREATE OR REPLACE FUNCTION public.notify_telegram(p_message text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = extensions, public
AS $$
DECLARE
  cfg record;
  url text;
  payload jsonb;
BEGIN
  SELECT bot_token, chat_id, is_enabled
  INTO cfg
  FROM telegram_config
  LIMIT 1;

  -- Silently skip if not configured or disabled
  IF NOT FOUND OR NOT cfg.is_enabled OR cfg.bot_token IS NULL OR cfg.chat_id IS NULL THEN
    RETURN;
  END IF;

  url := 'https://api.telegram.org/bot' || cfg.bot_token || '/sendMessage';
  payload := jsonb_build_object(
    'chat_id', cfg.chat_id,
    'text', p_message,
    'parse_mode', 'HTML'
  );

  -- Async, non-blocking HTTP POST — does not delay the INSERT
  PERFORM net.http_post(
    url := url,
    headers := jsonb_build_object('Content-Type', 'application/json'),
    body := payload
  );
END;
$$;